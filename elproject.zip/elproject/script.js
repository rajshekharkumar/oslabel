async function getMatchData() {
    try {
        const response = await fetch("https://api.cricapi.com/v1/currentMatches?apikey=50bac8e0-d5e8-4069-ac4e-68bf8f9e5403&offset=0");
        const data = await response.json();

        if (data.status !== "success") return;

        const matchesList = data.data;

        if (!matchesList) return [];

        const relevantData = [];

        for (const match of matchesList) {
            const teams = match.teams;
            const teamInfo = match.teamInfo.reduce((acc, team) => {
                acc[team.name] = team;
                return acc;
            }, {});
            const scores = {};
            match.score.forEach(score => {
                const [team, inning] = score.inning.split(' ');
                if (!scores[team]) {
                    scores[team] = {};
                }
                scores[team][inning] = score;
            });

            const matchData = {
                name: match.name,
                matchType: match.matchType,
                venue: match.venue,
                status: match.status,
                teams: teams,
                teamInfo: teamInfo,
                scores: scores
            };

            relevantData.push(matchData);
        }

        console.log({ relevantData });

        const matchesHTML = relevantData.map(match => `
            <li>
                <div>${match.name} (${match.matchType}) - ${match.venue}, ${match.status}</div>
                ${match.teams.map(team => {
                    const innings = match.scores[team];
                    const teamFlag = match.teamInfo[team]?.img;
                    if (!innings) return '';
                    let inningScoresHTML = '';
                    if (match.matchType === 'test') {
                        inningScoresHTML = Object.keys(innings).map(inning => `
                            ${inning}: Runs: ${innings[inning].r}, Wickets: ${innings[inning].w}, Overs: ${innings[inning].o}
                        `).join(', ');
                    } else if (match.matchType === 't20') {
                        const inning = Object.keys(innings)[0];
                        inningScoresHTML = `${inning}: Runs: ${innings[inning].r}, Wickets: ${innings[inning].w}, Overs: ${innings[inning].o}`;
                    }
                    return `
                        <div>
                            <img src="${teamFlag}" alt="${team}" width="48" height="48">
                            ${team} - ${inningScoresHTML}
                        </div>
                    `;
                }).join('')}
            </li>
        `).join('');

        document.getElementById("matches").innerHTML = matchesHTML;

        return relevantData;

    } catch (error) {
        console.log("Error fetching data: " + error.message);
    }
}

getMatchData();
